package com.atguigu.gmall.realtime.app

import java.util

import com.alibaba.fastjson.JSON
import com.atguigu.gmall.realtime.bean.{AlertInfo, EventLog}
import com.atguigu.gmall.realtime.util.MyKafkaUtil
import com.atguigu.gmallcommon.bean.{EsUtil, GmallConstant}
import org.apache.spark.SparkConf
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.{Minutes, Seconds, StreamingContext}

import scala.util.control.Breaks._


object AlertApp {
  def main(args: Array[String]): Unit = {
    val conf = new SparkConf().setMaster("local[*]").setAppName("AlertApp")
    val ssc = new StreamingContext(conf, Seconds(3))
    val sourceStream = MyKafkaUtil
      .getKafkaStream(ssc, GmallConstant.TOPIC_EVENT)
      .window(Minutes(5),Seconds(6))

    val eventLogStream: DStream[EventLog] =
      sourceStream.map(
        s => JSON.parseObject(s, classOf[EventLog]))

    val eventLogGrouped = eventLogStream
      .map(eventLog => (eventLog.mid, eventLog))
      .groupByKey()

    val alertInfoStream = eventLogGrouped.map {
      case (mid, eventLogs: Iterable[EventLog]) =>
        // 注意 这里需要使用java的集合，因为把数据写入es时，es不支持scala的集合(会导致取不出数据)
        // a: 存储最近5分钟登录过的所有用户，即当前的设备(mid)
        val uidSet: util.HashSet[String] = new util.HashSet[String]()
        // b: 存储5分钟内当前设备的所有事件
        val eventList: util.ArrayList[String] = new util.ArrayList[String]()
        // c: 存储领取的优惠券对应的那些产品id
        val itemSet: util.HashSet[String] = new util.HashSet[String]()
        // d: 是否点击商品,默认为 false
        var isClickItem: Boolean = false
        breakable {
          eventLogs.foreach((log) => {
            eventList.add(log.eventID) // 存储所有的事件
            log.eventID match {
              case "coupon" =>
                uidSet.add(log.uid) // 存储领取优惠卷的用户id
                itemSet.add(log.itemId) // 存储优惠卷对应的商品id
              case "clickItem" =>
                // 只要有一次浏览商品，就不会产生预警
                isClickItem = true
                break
              case _ =>
            }
          })
        }
        // 返回一个boolean值，预警信息 (是否需要预警，预警信息)
        (uidSet.size() >= 3 && !isClickItem, AlertInfo(mid, uidSet, itemSet, eventList, System.currentTimeMillis()))
    }

    // 把预警信息写入ES
    alertInfoStream
      .filter(_._1)
      .map(_._2)
      .foreachRDD(rdd=>{
        rdd.foreachPartition(alterInfos =>{
          val data = alterInfos.map(info =>
            (info.mid + ":"+ info.ts/1000/60,info))
          EsUtil.insertBulk("gmall_coupon_alert","_doc",data)
        })
      })
    alertInfoStream.print(10000)
    ssc.start()
    ssc.awaitTermination()
  }
}

/* 需求：同一设备，5分钟内三次以上使用不同账号登录，并领取优惠卷
* 并且在登录到领优惠卷中没有浏览商品，同时达到以上要求则产生一条预警信息
* 同一设备，每分钟只记录一次预警
*
* 1 从kafka消费数据
* 2 数据封装
* 3 实现需求
*   1 同一设备，按照设备id分组
*   2 5分钟内，使用window窗口，滑动步长为6s
*   3 三次及以上不同账号数量 聚合
*   4 领取优惠卷 filter 过滤
*   5 领取优惠卷中没有浏览商品
*       登录后没浏览商品
*   6 同一设备，每分钟只做一次预警
*/

