package com.atguigu.gmall.realtime.app

import java.text.SimpleDateFormat
import java.util
import java.util.Date

import com.alibaba.fastjson.JSON
import com.atguigu.gmall.realtime.bean.StartUpLog
import com.atguigu.gmall.realtime.util.{MyKafkaUtil, RedisUtil}
import org.apache.spark.SparkConf
import org.apache.spark.streaming.{Seconds, StreamingContext}
import com.atguigu.gmallcommon.bean.GmallConstant
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.streaming.dstream.DStream
import redis.clients.jedis.Jedis


object DuaApp {
  def main(args: Array[String]): Unit = {
    val conf: SparkConf = new SparkConf().setAppName("DuaApp").setMaster("local[*]")
    val ssc: StreamingContext = new StreamingContext(conf, Seconds(3))

    val sourceStream = MyKafkaUtil.getKafkaStream(ssc, GmallConstant.TOPIC_STARTUP)
    val startUpLogStream: DStream[StartUpLog] = sourceStream.map(jsonStr => JSON.parseObject(jsonStr, classOf[StartUpLog]))
    // 2 过滤去重得到的日期明细
    // 借助redis第三方工具实现去重
    val firstStartUpLogStream = startUpLogStream.transform(rdd => {
      // 从redis中读取已启动的设备数据
      val client = RedisUtil.getClient
      val key: String =
        GmallConstant.TOPIC_STARTUP + ":" + new SimpleDateFormat(
          "yy-MM-dd").format(new Date())
      val mids: util.Set[String] = client.smembers(key)
      client.close()
      // 把已经启动的设别过滤掉，rdd中只留下那些redis中不存在的记录
      // 使用广播器分发给集群
      val midsBd: Broadcast[util.Set[String]] = ssc.sparkContext.broadcast(mids)
      // 去重,同一批次内即3秒内，同一设备可能会启动两次，导致数据重复，在写入到hbase时会出问题
      val filterStartUpLogRdd =
        rdd.filter(log => !midsBd.value.contains(log.mid))
          .map(log => (log.mid, log))
          .groupByKey()
          .map {
            //              case (_,it) => it.toList.sortBy(_.ts).head
            case (_, it) => it.toList.minBy(_.ts)
          }
      filterStartUpLogRdd
    })

    firstStartUpLogStream.print(1000)

    // 3 把第一次启动的设备保存到redis中
    import org.apache.phoenix.spark._
    firstStartUpLogStream.foreachRDD(rdd => {
      rdd.foreachPartition(logIt => {
        val client: Jedis = RedisUtil.getClient
        logIt.foreach(log => {
          client.sadd(GmallConstant.TOPIC_STARTUP + ":" + log.logDate, log.mid)
        })
        client.close()
      })

      rdd.saveToPhoenix(GmallConstant.DAU_TABLE,
        Seq("MID", "UID", "APPID", "AREA", "OS", "CHANNEL", "LOGTYPE", "VERSION", "TS", "LOGDATE", "LOGHOUR"),
        zkUrl = Some(GmallConstant.ZKURL)
      )
    })


    ssc.start()
    ssc.awaitTermination()
  }
}
