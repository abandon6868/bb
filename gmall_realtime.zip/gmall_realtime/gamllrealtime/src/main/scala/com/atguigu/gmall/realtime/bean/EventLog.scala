package com.atguigu.gmall.realtime.bean

import java.text.SimpleDateFormat
import java.util.Date

case class EventLog(mid:String,
                    uid:String,
                    appId:String,
                    area:String,
                    os:String,
                    logType:String,
                    eventID:String,
                    pageId:String,
                    nextPageId:String,
                    itemId:String,
                    ts:Long,
                    var logDate:String = null,
                    var logHour:String = null
                   ){
  val date = new Date()
  logDate = new SimpleDateFormat("yyyy-MM-dd").format(date)
  logHour = new SimpleDateFormat("HH").format(date)
}
