package com.atguigu.gmall.realtime.app

import com.alibaba.fastjson.JSON
import com.atguigu.gmall.realtime.bean.{OrderDetail, OrderInfo, SaleDetail}
import com.atguigu.gmall.realtime.util.{MyKafkaUtil, RedisUtil}
import com.atguigu.gmallcommon.bean.GmallConstant
import org.apache.spark.SparkConf
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.json4s.DefaultFormats
import org.json4s.jackson.Serialization
import redis.clients.jedis.Jedis

object SaleDetailApp {

  /** *
   * 把数据写入客户端
   *
   * @param client redis 客户端
   * @param key    写入的key string
   * @param value  写入的 value 样例类
   * @return
   */
  def saveToRedis(client: Jedis, key: String, value: AnyRef) = {
    val json = Serialization.write(value)(DefaultFormats)
    //    client.set(key,json)  // 没法设置过滤时间
    // 添加过滤时间，超过30分钟之后这个key直接删除
    client.setex(key, 30 * 60, json)
  }

  /** *
   * 缓存 orderInfo
   *
   * @param client    redis 客户端
   * @param orderInfo redisInfo数据
   * @return
   */
  def cacheOrderInfo(client: Jedis, orderInfo: OrderInfo) = {
    val key: String = "order_info" + orderInfo.id
    saveToRedis(client, key, orderInfo)

  }

  /** *
   * 把orderDetail的数据写入reids缓存
   *
   * @param client
   * @param orderDetail
   * @return
   */
  def cacheOrderDetail(client: Jedis, orderDetail: OrderDetail) = {
    val key = s"order_detail:${orderDetail.order_id}:${orderDetail.id}"
    saveToRedis(client, key, orderDetail)
  }

  /** *
   * 对两个数据流进行fullOuterJoin
   *
   * @param orderInfoStream
   * @param orderDetailStream
   * @return
   */
  def streamFullJoin(orderInfoStream: DStream[(String, OrderInfo)],
                     orderDetailStream: DStream[(String, OrderDetail)]) = {
    orderInfoStream.fullOuterJoin(orderDetailStream).mapPartitions(it => {
      import scala.collection.JavaConversions._
      // 1 创建一个到redis的客户端
      val client: Jedis = RedisUtil.getClient

      // 2 对延时数据做处理,(如果返回一个就把一个放入集合中，如果返回时空，就返回一个空集合)
      val result = it.flatMap {
        // 在同一个时间戳的流里两张表的数据都存在
        case (orderId, (Some(orderInfo), Some(orderDetail))) =>
          println("some", "some")
          // 1 写入到缓冲区
          cacheOrderInfo(client, orderInfo)
          // 2 把OrderInfo 与orderDetail数据封装到样例类中
          val first = SaleDetail().mergeOrderInfo(orderInfo).mergeOrderDetail(orderDetail)
          // 3 去缓冲区中找已缓冲的orderDetail信息
          // 3.1 根据orderInfo去缓存中读取对应的 多个 orderDetail信息(集合)
          val keys = client.keys(s"order_detail:${orderId}:*").toList
          // 3.2 集合中会有多个orderDetail
          first :: keys.map(key => {
            val OrderDetailString = client.get(key)
            client.del(key) // 防止orderDetail倍重复join
            val orderDetail: OrderDetail = JSON.parseObject(OrderDetailString, classOf[OrderDetail])
            SaleDetail().mergeOrderInfo(orderInfo).mergeOrderDetail(orderDetail)
          })

        // 1 OrderInfo对应的流为空，OrderDetail有数据
        case (orderId, (None, Some(orderDetail))) =>
          println("none", "some")
          // 1 根据orderDetail中的 orderInfo.id 去redis缓冲区读取数据
          val orderInfoSting: String = client.get("order_info:" + orderId)

          // 2 读取之后，有可能读到orderInfo的信息，也有可能没督导，分两种情况
          // 2.1 读到数据，把数据封装到 SaleDetail 中
          if (orderInfoSting != null && orderInfoSting.nonEmpty) {
            val orderInfo = JSON.parseObject(orderInfoSting, classOf[OrderInfo])
            SaleDetail().mergeOrderInfo(orderInfo).mergeOrderDetail(orderDetail) :: Nil
          } else { // 2.2 读不到，把OrderDetail写到缓冲区
            cacheOrderDetail(client, orderDetail)
            Nil
          }

        // 3 OrderInfo的流有数据，OrderDetail没数据
        case (orderId, (Some(orderInfo), None)) =>
          println("some", "none")
          import scala.collection.JavaConversions._
          // 1 根据orderInfo去缓存中读取对应的 多个 orderDetail信息(集合)
          val keys = client.keys(s"order_detail:${orderId}:*").toList
          // 2 集合中会有多个orderDetail
          keys.map(key => {
            val OrderDetailString = client.get(key)
            client.del(key) // 防止orderDetail倍重复join
            val orderDetail: OrderDetail = JSON.parseObject(OrderDetailString, classOf[OrderDetail])
            SaleDetail().mergeOrderInfo(orderInfo).mergeOrderDetail(orderDetail)
          })
      }
      // 3 关闭客户端
      client.close()
      // 4 返回处理后的数据
      result
    })

  }

  def main(args: Array[String]): Unit = {
    val conf: SparkConf = new SparkConf().setAppName("SaleDetailApp").setMaster("local[*]")
    val ssc: StreamingContext = new StreamingContext(conf, Seconds(3))
    // 1 读取 kafka中的两个topic，得到两个流
    val orderInfoStream: DStream[(String, OrderInfo)] = MyKafkaUtil
      .getKafkaStream(ssc, GmallConstant.TOPIC_ORDER_INFO)
      .map(s => {
        val orderInfo = JSON.parseObject(s, classOf[OrderInfo])
        (orderInfo.id, orderInfo)
      })

    val orderDetailStream: DStream[(String, OrderDetail)] = MyKafkaUtil
      .getKafkaStream(ssc, GmallConstant.TOPIC_ORDER_DETAIL)
      .map(s => {
        val orderDetail = JSON.parseObject(s, classOf[OrderDetail])
        (orderDetail.order_id, orderDetail)
      })

    //    OrderInfoStream.print(1000)
    //    OrderDetailStream.print(1000)
    // 2 对这两个流做封装
    val saleDetail: DStream[SaleDetail] = streamFullJoin(orderInfoStream, orderDetailStream)
    saleDetail.print(1000)
    // 3 数据流进行join

    // 4 把详情写入es


    ssc.start()
    ssc.awaitTermination()
  }
}

/** *
 * 存储到redis中的数据类型
 * string
 * key                     value(字符串)
 * ”order_info:“+order_id    整个order_info的所有数据
 *
 * ”order_detail:“+order_id  整个order_detail的所有数据(json字符串)
 */


