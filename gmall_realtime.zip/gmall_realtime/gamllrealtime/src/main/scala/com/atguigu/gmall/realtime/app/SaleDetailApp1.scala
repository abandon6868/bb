package com.atguigu.gmall.realtime.app

import java.util.Properties

import com.alibaba.fastjson.JSON
import com.atguigu.gmall.realtime.bean.{OrderDetail, OrderInfo, SaleDetail, UserInfo}
import com.atguigu.gmall.realtime.util.{MyKafkaUtil, RedisUtil}
import com.atguigu.gmallcommon.bean.{EsUtil, GmallConstant}
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.json4s.DefaultFormats
import org.json4s.jackson.Serialization
import redis.clients.jedis.Jedis

object SaleDetailApp1 {

  /** *
   * 把数据写入客户端
   *
   * @param client redis 客户端
   * @param key    写入的key string
   * @param value  写入的 value 样例类
   * @return
   */
  def saveToRedis(client: Jedis, key: String, value: AnyRef) = {
    val json = Serialization.write(value)(DefaultFormats)
    //    client.set(key,json)  // 没法设置过滤时间
    // 添加过滤时间，超过30分钟之后这个key直接删除
    client.setex(key, 30 * 60, json)
  }

  /** *
   * 缓存 orderInfo
   *
   * @param client    redis 客户端
   * @param orderInfo redisInfo数据
   * @return
   */
  def cacheOrderInfo(client: Jedis, orderInfo: OrderInfo) = {
    val key: String = "order_info" + orderInfo.id
    saveToRedis(client, key, orderInfo)

  }

  /** *
   * 把orderDetail的数据写入reids缓存
   *
   * @param client
   * @param orderDetail
   * @return
   */
  def cacheOrderDetail(client: Jedis, orderDetail: OrderDetail) = {
    val key = s"order_detail:${orderDetail.order_id}:${orderDetail.id}"
    saveToRedis(client, key, orderDetail)
  }

  /** *
   * 对两个数据流进行fullOuterJoin
   *
   * @param orderInfoStream
   * @param orderDetailStream
   * @return
   */
  def streamFullJoin(orderInfoStream: DStream[(String, OrderInfo)],
                     orderDetailStream: DStream[(String, OrderDetail)]) = {
    orderInfoStream.fullOuterJoin(orderDetailStream).mapPartitions(it => {
      import scala.collection.JavaConversions._
      // 1 创建一个到redis的客户端
      val client: Jedis = RedisUtil.getClient

      // 2 对延时数据做处理,(如果返回一个就把一个放入集合中，如果返回时空，就返回一个空集合)
      val result = it.flatMap {
        // 1 OrderInfo对应的流为空，OrderDetail有数据
        case (orderId, (None, Some(orderDetail))) =>
          println("none", "some")
          // 1 根据orderDetail中的 orderInfo.id 去redis缓冲区读取数据
          val orderInfoSting: String = client.get("order_info:" + orderId)

          // 2 读取之后，有可能读到orderInfo的信息，也有可能没督导，分两种情况
          // 2.1 读到数据，把数据封装到 SaleDetail 中
          if (orderInfoSting != null && orderInfoSting.nonEmpty) {
            val orderInfo = JSON.parseObject(orderInfoSting, classOf[OrderInfo])
            SaleDetail().mergeOrderInfo(orderInfo).mergeOrderDetail(orderDetail) :: Nil
          } else { // 2.2 读不到，把OrderDetail写到缓冲区
            cacheOrderDetail(client, orderDetail)
            Nil
          }

        // 2 orderInfo流中有数据，orderDetail可能没数据
        case (orderId, (Some(orderInfo), opt)) =>
          // 1 写入缓存
          cacheOrderInfo(client, orderInfo)
          // 2 不管opt中是否有数据，都需要去 redis的缓存中读取数据
          val keys: List[String] = client.keys(s"order_detail:${orderId}:*").toList
          // 3 集合中会有多个 orderDetail
          keys.map(key => {
            val orderDetailString = client.get(key)
            client.del(key)
            val orderDetail = JSON.parseObject(orderDetailString, classOf[OrderDetail])
            SaleDetail().mergeOrderInfo(orderInfo).mergeOrderDetail(orderDetail)
          }) ::: (opt match {
            case Some(orderDetail) =>
              SaleDetail().mergeOrderInfo(orderInfo).mergeOrderDetail(orderDetail) :: Nil
            case None =>
              Nil
          })
      }
      // 3 关闭客户端
      client.close()
      // 4 返回处理后的数据
      result
    })

  }

  /** *
   * 使用sparksql 读取 mysql中的数据，然后把需要的字段添加到saleDetail中
   *
   * @param saleDetailStream orderInfo与orderDetail join 得到的流
   * @param ssc
   * @return
   */
  def joinUser(saleDetailStream: DStream[SaleDetail], ssc: StreamingContext) = {
    // 配置 mysql连接
    val url: String = "jdbc:mysql://hadoop102:3306/gmall1015"
    val prop: Properties = new Properties()
    prop.setProperty("user", "root")
    prop.setProperty("password", "admin")

    // 配置sparkSession
    val spark: SparkSession = SparkSession
      .builder()
      .config(ssc.sparkContext.getConf)
      .getOrCreate()
    import spark.implicits._
    // 1 把 mysql的数据读出来 ，每隔3s读一次
    saleDetailStream.transform(saleDetailRDD => {
      /*
         2 两种方案读取mysql数据
         2.1 如果数据两比较小，直接在driver中把数据读过来
         2.2 如果数据两比较大，每个分区读取一次
      */
      // 2.1 直接在driver中把数据读过来
      val userInfoRdd = spark.read.jdbc(url,
        GmallConstant.USER_INFO_TABLE,
        prop)
        .as[UserInfo]
        .rdd
        .map(user => (user.id, user))

      val saleDetail: RDD[SaleDetail] = saleDetailRDD.map(saleDetail => (saleDetail.user_id, saleDetail))
        .join(userInfoRdd)
        .map {
          case (_, (saleDetail, userInfo)) =>
            saleDetail.mergeUserInfo(userInfo)
        }
      saleDetail
    })
  }

  def writeStreamToEs(saleDetailStream: DStream[SaleDetail]) = {

    saleDetailStream.foreachRDD(rdd => {
      // 方法1 可以把rdd的所有数据拉取到驱动端写入[优点效率高，到es值创建了一个连接，
      //  缺点，如果此批次的数据量过大时，回给 driver端造成很大的内存压力，可能导致oom]
      EsUtil.insertBulk(GmallConstant.ES_SALE_DETAIL_INDEX,
        GmallConstant.ES_SALE_DETAIL_TYPE,
        rdd.collect().toIterator)
      // 方法2 每个分区分别去写[优点：不会造成oom，缺点：每个分区都会产生一个ES链接]
/*      rdd.foreachPartition(it => {
        EsUtil.insertBulk(GmallConstant.ES_SALE_DETAIL_INDEX,
          GmallConstant.ES_SALE_DETAIL_TYPE, it)
      })*/
    })

  }

  def main(args: Array[String]): Unit = {
    val conf: SparkConf = new SparkConf()
      .setAppName("SaleDetailApp")
      .setMaster("local[*]")
    val ssc: StreamingContext = new StreamingContext(conf, Seconds(3))
    // 1 读取 kafka中的两个topic，得到两个流
    // 2 对这两个流做封装(join必须是kv形式的，k是join的条件)
    val orderInfoStream: DStream[(String, OrderInfo)] = MyKafkaUtil
      .getKafkaStream(ssc, GmallConstant.TOPIC_ORDER_INFO)
      .map(s => {
        val orderInfo = JSON.parseObject(s, classOf[OrderInfo])
        (orderInfo.id, orderInfo)
      })

    val orderDetailStream: DStream[(String, OrderDetail)] = MyKafkaUtil
      .getKafkaStream(ssc, GmallConstant.TOPIC_ORDER_DETAIL)
      .map(s => {
        val orderDetail = JSON.parseObject(s, classOf[OrderDetail])
        (orderDetail.order_id, orderDetail)
      })

    //    OrderInfoStream.print(1000)
    //    OrderDetailStream.print(1000)
    // 3 对这两个流做封装
    var saleDetailStream: DStream[SaleDetail] = streamFullJoin(orderInfoStream, orderDetailStream)
    // 4 根据用户id，反查user_info表，得到用户的生日和性别
    saleDetailStream = joinUser(saleDetailStream, ssc)
    saleDetailStream.print(1000)
    // 4 把详情写入es
    writeStreamToEs(saleDetailStream)

    ssc.start()
    ssc.awaitTermination()
  }
}

/** *
 * 存储到redis中的数据类型
 * string
 * key                     value(字符串)
 * ”order_info:“+order_id    整个order_info的所有数据
 *
 * ”order_detail:“+order_id  整个order_detail的所有数据(json字符串)
 */


