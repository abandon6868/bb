package com.atguigu.gmall.realtime.util

import kafka.serializer.StringDecoder
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.kafka.KafkaUtils
import com.atguigu.gmallcommon.bean.GmallConstant

object MyKafkaUtil {

  val params = Map[String,String](
    "bootstrap.servers" ->GmallConstant.kafka_cluster ,
    "group.id" -> GmallConstant.kafka_groupid
  )

  def getKafkaStream(ssc:StreamingContext, topic:String, otherTopics:String*): DStream[String] ={
    KafkaUtils.createDirectStream[String,String,StringDecoder,StringDecoder](
      ssc,
      params,
      (otherTopics :+ topic).toSet
    ).map(_._2)
  }
}
