package com.atguigu.gmall.realtime.util

import redis.clients.jedis.Jedis

object RedisUtil {
  val host = ConfigUtil.getProperty("redis.host")
  val port = ConfigUtil.getProperty("redis.port").toInt
  def getClient: Jedis = {
    val client: Jedis = new Jedis(host, port, 60 * 1000)
    client.connect()
    client
  }
}
