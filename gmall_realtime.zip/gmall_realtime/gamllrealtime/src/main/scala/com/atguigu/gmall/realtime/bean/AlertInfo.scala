package com.atguigu.gmall.realtime.bean
import java.util

case class AlertInfo(mid:String,
                     uids:util.HashSet[String],
                     itemIds:util.HashSet[String],
                     events:util.List[String],
                     ts:Long
                    )
