package com.atguigu.gmallcommon.bean

import io.searchbox.client.{JestClient, JestClientFactory}
import io.searchbox.client.config.HttpClientConfig
import io.searchbox.core.{Bulk, Index}

object EsUtil {
  // es集群地址
  private val esURL = "http://hadoop102:9200"

  def get_esFactory(): JestClientFactory ={

    val factory = new JestClientFactory
    val conf = new HttpClientConfig.Builder(esURL)
      .maxTotalConnection(100) // 最多同时可以有100个到es的客户端，要大于分区数
      .connTimeout(10 * 1000) // 连接到es的超时时间
      .readTimeout(10 * 1000) // 读取数据的时候的超时时间
      .multiThreaded(true) // 是否允许多线程
      .build()
    factory.setHttpClientConfig(conf)
    factory
  }

  /**
   * 向es中插入单条数据
   * @param index  index
   * @param `type` type
   * @param source 数据源
   * @param id 单条数据的id，如果为null，表示id为随机生成
   */
  def insertSingle(index:String,`type`:String,source:Object,id:String=null) ={
    val factory = get_esFactory()
    val client: JestClient = factory.getObject
    val action = new Index.Builder(source)
      .index(index)
      .`type`(`type`)
      .id(id) // 可选参数，如果没设置，默认设置随机值
      .build()
    client.execute(action)
    client.shutdownClient()
  }

  /**
   * 向es中插入多条数据
   * 迭代器中的[ANY]的类型
   *  1 样例类(json字符串) 表示这个doc的id自动生产
   *  2 (id,data) 元组，第一个是id，第二个是数据
   * @param index  index
   * @param `type` type
   * @param sources 数据源
   */
  def insertBulk(index: String, `type`: String,sources:Iterator[Any]): Unit ={
    val factory = get_esFactory()
    val client = factory.getObject

    val bulk: Bulk.Builder = new Bulk.Builder()
      .defaultIndex(index)
      .defaultType(`type`)

    sources.foreach{
      case (id:String,data) =>
        val action: Index = new Index.Builder(data).id(id).build()
        bulk.addAction(action)
      case data =>
        val action: Index = new Index.Builder(data).build()
        bulk.addAction(action)
    }
    client.execute(bulk.build())
    client.shutdownClient()

  }

  def insertBulk_test(index:String,`type`:String): Unit ={
    val factory = get_esFactory()
    val user1 = new User(20, "hanwudi")
    val index1 = new Index.Builder(user1).build()
    val user2 = new User(40, "qinshihuang")
    val index2 = new Index.Builder(user2).build()

    val client: JestClient = factory.getObject
    val bulk = new Bulk.Builder()
      .defaultIndex(index)
      .defaultType(`type`)
      .addAction(index1)
      .addAction(index2)
      .build()

    client.execute(bulk)
    client.shutdownClient()
  }

  def main(args: Array[String]): Unit = {
//    val list = User(1,"AA")::User(2,"BB")::User(3,"CC")::Nil
//    insertBulk("user","_doc",list.toIterator)

    val list2 = ("100",User(1,"AA"))::("200",User(2,"BB"))::("300",User(3,"CC"))::Nil
    insertBulk("user","_doc",list2.toIterator)
  }
}

case class User(age:Int,name:String)