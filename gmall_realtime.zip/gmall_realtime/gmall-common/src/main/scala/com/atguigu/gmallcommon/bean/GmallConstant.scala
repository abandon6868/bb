package com.atguigu.gmallcommon.bean

object GmallConstant {
  val TOPIC_STARTUP = "topic_startup1015"
  val TOPIC_EVENT = "topic_event1015"

  // kafka cluster
  val kafka_cluster= "hadoop102:9092,hadoop103:9092,hadoop104:9092"
  val kafka_groupid = "gmall1015"

  // dau 的phoenix表  shift+ctrl+u 大小写切换的快捷键
  val DAU_TABLE = "GMALL_DAU1015"

  val TOPIC_ORDER_INFO = "topic_order_info"
  val TOPIC_ORDER_DETAIL = "topic_order_detail"

  val INDEX_ALTER = "gmall_coupon_alert1015"
  val INDEX_SALE_DETAIL = "sale_detail_1015"

  val ZKURL = "hadoop102,hadoop103,hadoop104:2181"
}
