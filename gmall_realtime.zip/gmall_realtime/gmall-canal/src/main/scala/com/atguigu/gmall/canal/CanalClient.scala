package com.atguigu.gmall.canal

import java.net.InetSocketAddress
import java.util

import com.alibaba.fastjson.JSONObject

import scala.collection.JavaConversions._
import com.alibaba.otter.canal.client.CanalConnectors
import com.alibaba.otter.canal.protocol.CanalEntry.{EntryType, EventType, RowChange}
import com.alibaba.otter.canal.protocol.{CanalEntry, Message}
import com.atguigu.gmallcommon.bean.GmallConstant
import com.google.protobuf.ByteString

import scala.util.Random

object CanalClient {

  def main(args: Array[String]): Unit = {
    // 1 链接canal
    val address = new InetSocketAddress("hadoop102", 11111)
    val connector = CanalConnectors.newSingleConnector(
      address, "example", "", "")
    connector.connect() // 连接
    // 1.1 订阅数据,订阅此库下的所有的表
    connector.subscribe("gmall1015.*")
    // 2 读数据，解析数据
    while (true) { // 使用循环一直读取数据
      val message: Message = connector.get(100) // 一次从canal拉取100条变化的sql数据
      // 一个entry 封装一条sql
      // val entries: util.List[CanalEntry.Entry] = if(message != null) message.getEntries else None
      val entriesOption: Option[util.List[CanalEntry.Entry]] = if (message != null) Some(message.getEntries) else None
      if (entriesOption.isDefined && entriesOption.get.nonEmpty) {
        val entries: util.List[CanalEntry.Entry] = entriesOption.get
        for (entry <- entries) {
          if (entry != null && entry.hasEntryType && entry.getEntryType == EntryType.ROWDATA) {
            // 从每个 entry中获取一个storeValue
            val storeValue: ByteString = entry.getStoreValue
            // 使用 RowChange 工具 解析 storeValue，得到 rowChange
            val rowChange = RowChange.parseFrom(storeValue)
            // 一个 storeValue 中有多个 RowData, 每个 RoweData 表示一行数据的变化
            val rowDatas: util.List[CanalEntry.RowData] = rowChange.getRowDatasList
            // 解析 rowDatas 中每行的数据
            handleData(entry.getHeader.getTableName, rowDatas, rowChange.getEventType)
          }
        }
      } else {
        println("没有拉取到数据，2s之后重新拉取")
        Thread.sleep(2000)
      }
    }

    // 3 把数据转成json字符串，写入到Kafka
  }

  def handleData(tableName: String,
                 rowDatas: util.List[CanalEntry.RowData],
                 eventType: CanalEntry.EventType): Unit = {
    if (tableName == "order_info" && eventType == EventType.INSERT && rowDatas != null && rowDatas.nonEmpty) {
      sendToKafka(GmallConstant.TOPIC_ORDER_INFO, rowDatas)
    } else if (tableName == "order_detail" && eventType == EventType.INSERT && rowDatas != null && rowDatas.nonEmpty) {
      sendToKafka(GmallConstant.TOPIC_ORDER_DETAIL, rowDatas)
    }
  }

  def sendToKafka(topic: String, rowDatas: util.List[CanalEntry.RowData]): Unit = {
    for (rowData <- rowDatas) {
      val result: JSONObject = new JSONObject()
      // 一行所有变化后的列
      val columnsList = rowData.getAfterColumnsList
      for (column <- columnsList) {
        val key = column.getName
        val value = column.getValue
        result.put(key, value)
      }
      println(result.toJSONString)
      // 把数据写入kafka
      // MyKafkaUtil.send(topic,result.toJSONString)
      // 模拟延时情况
      new Thread() {
        override def run(): Unit = {
          Thread.sleep(new Random().nextInt(20 * 1000))
          MyKafkaUtil.send(topic, result.toJSONString)
        }
      }.start()
    }

  }
}


